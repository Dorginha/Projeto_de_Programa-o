package me04.TestePolimorfismo;

public class Super {
    public void print(){
        System.out.println("SuperClasse");
    }
}