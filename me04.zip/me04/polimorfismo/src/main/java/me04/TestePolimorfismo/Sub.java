package me04.TestePolimorfismo;

public class Sub extends Super{
    public void print(){
        System.out.println("SubClasse");
    }
}
