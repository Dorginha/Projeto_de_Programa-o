package me04.Oficina;

public class Veiculo {
    public void verificaLista(){
        System.out.println("Verifica veículo");
    }
    public void reparar(){
        System.out.println("Repara veículo");
    }
    public void lavar(){
        System.out.println("Lava veículo");
    }
}
