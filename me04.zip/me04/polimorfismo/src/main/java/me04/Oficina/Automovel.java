package me04.Oficina;

public class Automovel extends Veiculo{
    public void verificaLista(){
        System.out.println("Verifica automovel");
    }
    public void reparar(){
        System.out.println("Reparar automovel");
    }
    public void lava(){
        System.out.println("Lavar automovel");
    }
}
