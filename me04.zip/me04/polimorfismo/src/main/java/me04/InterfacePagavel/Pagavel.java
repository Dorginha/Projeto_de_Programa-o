package me04.InterfacePagavel;

public interface Pagavel {
    double getValorAPagar();
}
